package com.msvc.kubernetes.usuarios.models;

public class Curso {
}
